# ATM Simulation System

## About the Project

This is a simple ATM Simulation project developed using Java and Object-Oriented Programming concepts.

The program allows the user to enter a PIN, check the account balance, deposit money, withdraw money, and exit the ATM system.

## Features

- PIN verification
- Check account balance
- Deposit money
- Withdraw money
- Insufficient balance checking
- Invalid amount checking
- Simple console-based interface

## Technologies Used

- Java
- Object-Oriented Programming
- Scanner
- Switch Case
- Loops
- Conditional Statements

## How to Run

Compile:

```bash
javac ATMSimulation.java
```

Run:

```bash
java ATMSimulation
```

## Default PIN

```text
1234
```

## Starting Balance

```text
₹10,000
```

## Project Structure

```text
ATM-Simulation-Java/
├── ATMSimulation.java
├── README.md
└── .gitignore
```

## Future Improvements

- Add multiple bank accounts
- Add transaction history
- Add PIN change option
- Add a graphical user interface
- Connect the project to a database
- Add account creation and management
